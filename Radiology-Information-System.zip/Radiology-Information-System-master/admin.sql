INSERT INTO persons VALUES (
	0, 'administrator', 'administrator', 'address', 'admin@ris.com', 'phone'
);

INSERT INTO users VALUES (
	'admin', 'password', 'a', 0, CURRENT_DATE
);